package com.utn.ejer1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejer1Application {

	public static void main(String[] args) {
		SpringApplication.run(Ejer1Application.class, args);
	}

}
