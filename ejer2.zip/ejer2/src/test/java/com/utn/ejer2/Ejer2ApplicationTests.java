package com.utn.ejer2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejer2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
